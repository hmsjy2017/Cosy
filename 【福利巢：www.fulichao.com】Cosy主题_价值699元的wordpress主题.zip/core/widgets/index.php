<?php

/*
            /$$            
    /$$    /$$$$            
   | $$   |_  $$    /$$$$$$$
 /$$$$$$$$  | $$   /$$_____/
|__  $$__/  | $$  |  $$$$$$ 
   | $$     | $$   \____  $$
   |__/    /$$$$$$ /$$$$$$$/
          |______/|_______/ 
================================
        Keep calm and get rich.
                    Is the best.

  	@Author: Dami
  	@Date:   2017-09-11 15:54:17
  	@Last Modified by:   Dami
  	@Last Modified time: 2017-09-11 18:10:49

*/
if ( ! defined( 'ABSPATH' ) ) { die; }

include( 'related-posts.php' );

include( 'posts-aggregation.php' );